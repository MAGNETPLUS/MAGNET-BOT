rocks_trees = {
   { name = [[system]], root = [[/home/bot4/MaTaDoR-Company/.luarocks]] }
}
